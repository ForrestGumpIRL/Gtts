import Core.t_t_s as t

from clrprint import *

import time

while True:
    t.Help()

    Help = clrinput("What do you want to do now(Help, Lang or Credits)?", clr="y")

    if Help == "Credits":
        t.Credits()
    if Help == "Lang":
        t.Lang()
    else:
        t.Help()
    time.sleep(10)
