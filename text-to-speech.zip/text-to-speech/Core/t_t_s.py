# Import the required module for text 
# to speech conversion
from gtts import gTTS
  
# This module is imported so that we can 
# play the converted audio
import os

from clrprint import *

Language = 'en'

Mytext = 'Test'

Name = "test"

def Speech(Mytext, Name, Language = "en", Tempo = False):

    
    # Passing the text and language to the engine, 
    # here we have marked slow=False. Which tells 
    # the module that the converted audio should 
    # have a high speed
    myobj = gTTS(text=Mytext, lang=Language, slow=Tempo)
      
    # Saving the converted audio in a mp3 file named
    # welcome 
    myobj.save("{}.mp3".format(Name))
      
    # Playing the converted file
    os.system("mpg321 {}.mp3".format(Name))

def speak():
    speech("en", "Hello", "MyTest")

def Lang():

    print("""
    af: Afrikaans,
    ar: Arabic,
    bg: Bulgarian,
    bn: Bengali,
    bs: Bosnian,
    ca: Catalan,
    cs: Czech,
    cy: Welsh,
    da: Danish,
    de: German,
    el: Greek,
    en: English,
    eo: Esperanto,
    es: Spanish,
    et: Estonian,
    fi: Finnish,
    fr: French,
    gu: Gujarati,
    hi: Hindi,
    hr: Croatian,
    hu: Hungarian,
    hy: Armenian,
    id: Indonesian,
    is: Icelandic,
    it: Italian,
    ja: Japanese,
    jw: Javanese,
    km: Khmer,
    kn: Kannada,
    ko: Korean,
    la: Latin,
    lv: Latvian,
    mk: Macedonian,
    ml: Malayalam,
    mr: Marathi,
    my: Myanmar (Burmese),
    ne: Nepali,
    nl: Dutch,
    no: Norwegian,
    pl: Polish,
    pt: Portuguese,
    ro: Romanian,
    ru: Russian,
    si: Sinhala,
    sk: Slovak,
    sq: Albanian,
    sr: Serbian,
    su: Sundanese,
    sv: Swedish,
    sw: Swahili,
    ta: Tamil,
    te: Telugu,
    th: Thai,
    tl: Filipino,
    tr: Turkish,
    uk: Ukrainian,
    ur: Urdu,
    vi: Vietnamese,
    zh-CN: Chinese
    """)

def Credits():
    clrprint("    Coding: Amund Aukland-Våge\n","   Formatting: Amund Aukland-Våge\n", "    Voices: Google Translate\n", clr="r,y,p")

def Help():
    clrprint(""" Here are the functions you can use:""", """

                .Help(): writes the available functions
                

                
                .Speech(Mytext, Name, Language, Tempo): Makes and saves a mp3 file""", """
                
                    Mytext: Here you write the str converted into speech. Can either be a variable or direct string value.
                    
                    Name: Here you write the name of the file, in string format. Can either be a variable or dir. string value.

                    Language: Chooses the language used. type "en" for english, "de" for german, etc. Start value is "en". THIS PARAMETER IS NOT NEEDED
                    
                    Tempo: Here you write 'True' if the text should be read slow, and 'False' if the text should be read in normal speed. THIS PARAMETER IS NOT NEEDED

                    """, """

                    
                .Lang(): Shows all available languages, with the abbreviation showing what needs to be typed in the Language parameter at the .Speech function.



                .Credits(): Shows the credits for this project.

                    """, clr="y,b,p,b")

