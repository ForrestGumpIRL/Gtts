import sys

color = sys.stdout.shell

MyText = "Test"


def Color(MyText, MyColor):


    if MyColor == "purple":
        TColor = "BUILTIN"

    if MyColor == "blue":
        TColor = "DEFINITION"

    if MyColor == "red-bg":
        TColor = "ERROR"
        
    if MyColor == "orange":
        TColor = "KEYWORD"
        
    if MyColor == "green":
        TColor = "STRING"
        
    if MyColor == "red":
        TColor = "COMMENT"

    if MyColor == "cyan":
        TColor = "sel"
        
    
    color.write(MyText, TColor)
    
