import clrprint as clr
clr.clrhelp()  # to see colors available

def Color(MyText, MyColor):
    clr.clrprint(MyText, clr=MyColor)  # just like print()
