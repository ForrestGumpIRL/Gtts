import Core.t_t_s as t

import configparser

import os



parser = configparser.ConfigParser()
parser.read("Config.txt")


PATH = "Source/"


#FileName = "Test.txt"


FileName = parser.get("config", "FileName")


Fileimp = ("{}{}".format(PATH, FileName))




File = open(Fileimp, "r").read().replace("\n", " ")


Lang = parser.get("config", "Lang")


if (parser.get("config", "Speed")) == "Fast":
    Slow = False
else:
    Slow = True

#fileimp = fileimp.replace(".txt", "")

FileName = os.path.splitext(Fileimp)[0]

t.Speech(File, FileName, Lang, Slow)

