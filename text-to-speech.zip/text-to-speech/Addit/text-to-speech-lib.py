# Import the required module for text 
# to speech conversion
from gtts import gTTS
  
# This module is imported so that we can 
# play the converted audio
import os

Language = 'en'

Mytext = 'Test'

Name = "test"

def Speech(Mytext, Name, Language = "en", Tempo = False):

    
    # Passing the text and language to the engine, 
    # here we have marked slow=False. Which tells 
    # the module that the converted audio should 
    # have a high speed
    myobj = gTTS(text=Mytext, lang=Language, slow=Tempo)
      
    # Saving the converted audio in a mp3 file named
    # welcome 
    myobj.save("{}.mp3".format(Name))
      
    # Playing the converted file
    os.system("mpg321 {}.mp3".format(Name))

def speak():
    speech("en", "Hello", "MyTest")

def Help():
    print(""" Here are the functions you can use:

                .Help(): writes the available functions
                
                
                .Speech(Mytext, Name, Language, Tempo): makes and saves a mp3 file
                
                    Mytext: here you write the str converted into speech. Can either be a variable or direct string value.
                    
                    Name: here you write the name of the file, in string format. Can either be a variable or dir. string value.

                    Language: chooses the language used. type "en" for english, "de" for german, etc. Start value is "en". THIS PARAMETER IS NOT NEEDED
                    
                    Tempo: Here you write 'True' if the text should be read slow, and 'False' if the text should be read in normal speed. THIS PARAMETER IS NOT NEEDED

                    """)

